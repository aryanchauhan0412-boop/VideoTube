import { User } from "../models/user.models.js";
import { ApiError } from "../utils/ApiError.js";
import { asynchandler } from "../utils/asynchandler.js";
import jwt from "jsonwebtoken"

export const verifyJWT = asynchandler(async (req, res, next) => {
  // console.log("verify jwt called");
  // console.log(req.cookies);
  try {
    const token = req.cookies?.accessToken || req.header("Authorization")?.replace("Bearer ", "");
    // console.log(token);
  
    if(!token){
      throw new ApiError(401, "Unauthorized request")
    }
  
    const decodedToken = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET)

    // console.log("Decoeded: ", decodedToken);
    
  
    const user = await User.findById(decodedToken._id).select("-password -refreshToken")
    
    if(!user){
      throw new ApiError(401, "Invalid Access Token")
    }
  
    req.user = user;
    next()
  } catch (error) {
      throw new ApiError(401, error?.message || "Invalid access token")
  }

})